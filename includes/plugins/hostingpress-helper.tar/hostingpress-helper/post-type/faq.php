<?php

/* Create the FAQ custom post type */

if(!function_exists('hostingpress_create_faq_post_type'))
{
    function hostingpress_create_faq_post_type()
    {
        $labels = array(
            'name'          => esc_html__('FAQs','hostingpress'),
            'singular_name' => esc_html__('FAQ','hostingpress'),
            'add_new'       => esc_html__('Add New','hostingpress'),
            'add_new_item'  => esc_html__('Add New FAQ','hostingpress'), //The add new item text. Default is Add New Post/Add New Page
            'edit_item'     => esc_html__('Edit FAQ','hostingpress'), //The edit item text. In the UI, this label is used as the main header on the post's editing panel. The default is "Edit Post" for non-hierarchical and "Edit Page" for hierarchical post types.
            'new_item'      => esc_html__('New FAQ','hostingpress'), //The new item text. Default is "New Post" for non-hierarchical and "New Page" for hierarchical post types.
            'view_item'     => esc_html__('View FAQ','hostingpress'), //The view item text. Default is View Post/View Page
            'search_items'  => esc_html__('Search FAQ','hostingpress'), //The search items text. Default is Search Posts/Search Pages
            'not_found'     =>  esc_html__('No FAQ found','hostingpress'), //The not found text. Default is No posts found/No pages found
            'not_found_in_trash' => esc_html__('No FAQ found in Trash','hostingpress'), //The not found in trash text. Default is No posts found in Trash/No pages found in Trash.
            'parent_item_colon' => '' //The parent text. This string is used only in hierarchical post types. Default is "Parent Page".
        );

        $args = array(
            'labels'        => $labels, //labels - An array of labels for this post type. By default, post labels are used for non-hierarchical post types and page labels for hierarchical ones.
            'public'        => true, //Controls how the type is visible to authors (show_in_nav_menus, show_ui) and readers
            'hierarchical'  => false, //Whether the post type is hierarchical (e.g. page). Allows Parent to be specified. The 'supports' parameter should contain 'page-attributes' to show the parent select box on the editor page.
            'menu_position' => 5, //The position in the menu order the post type should appear. show_in_menu must be true.
            'supports'      => array('title','editor','thumbnail'), // Possible attributes (title, editor, author, thumbnail, excerpt, trackbacks, custom-fields, comments, revisions, page-attributes, post-formats)
            'rewrite'       => array('slug' => 'faq'), // Triggers the handling of rewrites for this post type. To prevent rewrites, set to false.
            'exclude_from_search' => true, //Whether to exclude posts with this post type from front end search results.
            'publicly_queryable' => true //Whether queries can be performed on the front end as part of parse_request().
        );

        register_post_type('faq', $args);
    }
}
add_action('init', 'hostingpress_create_faq_post_type');

/* Create Doctor Type Taxonomy */
if (!function_exists('create_faq_categories_taxonomy')) {
    function create_faq_categories_taxonomy()
    {
        $faq_labels = array(
            'name' => __( 'FAQ Categories', 'hostingpress' ),
            'singular_name' => __( 'FAQ Category', 'hostingpress' ),
            'search_items' =>  __( 'Search FAQ Category', 'hostingpress' ),
            'popular_items' => __( 'Popular FAQ Category', 'hostingpress' ),
            'all_items' => __( 'All FAQ Categories', 'hostingpress' ),
            'parent_item' => __( 'Parent FAQ Category', 'hostingpress' ),
            'parent_item_colon' => __( 'Parent FAQ Category:', 'hostingpress' ),
            'edit_item' => __( 'Edit FAQ Category', 'hostingpress' ),
            'update_item' => __( 'Update FAQ Category', 'hostingpress' ),
            'add_new_item' => __( 'Add New FAQ Category', 'hostingpress' ),
            'new_item_name' => __( 'New FAQ Category Name', 'hostingpress' ),
            'separate_items_with_commas' => __( 'Separate Categories with commas', 'hostingpress' ),
            'add_or_remove_items' => __( 'Add or remove FAQ Category', 'hostingpress' ),
            'choose_from_most_used' => __( 'Choose from the most used Categories', 'hostingpress' ),
            'menu_name' => __( 'FAQ Categories', 'hostingpress' )
        );

        register_taxonomy(
            'faqcategory',
            array( 'faq'),
            array(
                'hierarchical' => true,
                'labels' => $faq_labels,
                'show_ui' => true,
                'query_var' => true,
                'rewrite' => array('slug' => __('faqcategory', 'hostingpress'))
            )
        );
    }
}

add_action('init', 'create_faq_categories_taxonomy', 0);
