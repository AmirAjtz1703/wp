<?php

/* Create the Mega Menu custom post type */


if( !function_exists( 'hosting_press_helper_init' ) ){
	
	/* Add post type */

	function hosting_press_helper_init() {
	
		if( !post_type_exists( 'mega_menu' ) ){
			$labels = array(
		        'name' => __('HP - Mega Menu', 'hostingpress'),
		        'singular_name' => __('HP - Mega Menu', 'hostingpress'),
		        'add_new' => __('Add New', 'hostingpress'),
		        'add_new_item' => __('Add New HP Mega Menu Item', 'hostingpress'),
		        'edit_item' => __('Edit HP Mega Menu Item', 'hostingpress'),
		        'new_item' => __('New HP Mega Menu Item', 'hostingpress'),
		        'view_item' => __('View HP Mega Menu Item', 'hostingpress'),
		        'search_items' => __('Search HP Mega Menu Items', 'hostingpress'),
		        'not_found' => __('No HP Mega Menu Items found', 'hostingpress'),
		        'not_found_in_trash' => __('No HP Mega Menu Items found in Trash', 'hostingpress'),
		        'parent_item_colon' => __('Parent HP Mega Menu Item:', 'hostingpress'),
		        'menu_name' => __('Mega Menu', 'hostingpress'),
		    );
		
		    $args = array(
		        'labels' => $labels,
		        'hierarchical' => false,
		        'description' => __('Mega Menus entries for Slowave.', 'hostingpress'),
		        'supports' => array('title', 'editor'),
		        'public' => true,
		        'show_ui' => true,
		        'show_in_menu' => true,
		        'menu_position' => 40,
		        'show_in_nav_menus' => true,
		        'publicly_queryable' => false,
		        'exclude_from_search' => true,
		        'has_archive' => false,
		        'query_var' => true,
		        'can_export' => true,
		        'rewrite' => false,
		        'capability_type' => 'post'
		    );
			
		    register_post_type('mega_menu', $args);
		}    
		
	}
	add_action( 'init', 'hosting_press_helper_init',0 );
	  

}	 
