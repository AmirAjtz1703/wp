<?php

if(!function_exists('hostingpress_vc_team'))
{
    function hostingpress_vc_team() {
        vc_map( array(
            "name"  => esc_html__("Teams", "hostingpress" ),
            "base"  => "hostingpress_team",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("SUPPORTED STAFF &", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("OUR TEAM", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Teams", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Teams", "hostingpress"),
                    'value'         => 3
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2'),
                    "std"           => 'Layout1',
                ),
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_team');


if(!function_exists('hostingpress_vc_team_shortcode'))
{
    function hostingpress_vc_team_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('SUPPORTED STAFF &', "hostingpress"),
			'title' => esc_html__('OUR TEAM', "hostingpress"),
            'limit' => 6,
			'template' => 'Layout1',
        ), $atts);

        $query_arg = array(
            'post_type' => 'team'
        );

        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }


        $our_team = new WP_Query();
        $our_team->query($query_arg);
		ob_start();

		if($atts['template'] == 'Layout1')
        {
			?>
			<div class="row">
            <div class="container">
                <div class="row sectionTitle">
                    <h5><?php echo esc_html($atts['sub_title']) ?></h5>
                    <h2><?php echo esc_html($atts['title']) ?></h2>
                </div>
                <div class="row">

			<?php

				while($our_team->have_posts()) : $our_team->the_post();
				$post_meta = get_post_meta(get_the_ID());
				
				?>
                    <div class="col-sm-4 team_member">
                        <div class="row m0 inner">
                            <div class="row m0 image"><?php the_post_thumbnail('hostingpress-team-thumb', array('class' => 'img-responsive')); ?></div>
                            <h4 class="title"><?php the_title(); ?></h4>
                            <h6 class="desig"><?php echo esc_html($post_meta['team_designation'][0]); ?></h6>
                            <p class="nState"><?php echo esc_html($post_meta['team_introduction_text'][0]); ?></p>
                            <p class="hState"><?php echo hostingpress_excerpt(200); ?></p>
                            <ul class="list-unstyled">
                                <li><a href="<?php echo esc_url($post_meta['team_facebook_url'][0]); ?>"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="<?php echo esc_url($post_meta['team_twitter_url'][0]); ?>"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="<?php echo esc_url($post_meta['team_google_plus_url'][0]); ?>"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="<?php echo esc_url($post_meta['team_linkedin_url'][0]); ?>"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>

			<?php

			endwhile;
			?>
			</div>
			</div>
			</div>
			
			<?php
			}
        wp_reset_postdata();
		return ob_get_clean();
    }
}
add_shortcode('hostingpress_team', 'hostingpress_vc_team_shortcode');