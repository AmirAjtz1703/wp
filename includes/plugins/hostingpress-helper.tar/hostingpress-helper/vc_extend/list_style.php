<?php

if(!function_exists('vc_hostingpress_list_section'))
{
    function vc_hostingpress_list_section() {
        vc_map( array(
            "name"  => __("Listing Style", "hostingpress" ),
            "base"  => "hostingpress_liststyle",
            "class" => "",
            "category" => __("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    'heading'		=> esc_html__( 'List Details', 'hostingpress' ),
                    'description'	=> esc_html__( 'Enter Tab name and Tab Id  ', 'hostingpress' ),
                    'type'			=> 'param_group',
                    'param_name'	=> 'list_details',
                    'params' => array(
                        array(
                            'heading'	 => esc_html__( 'List Item Name', 'hostingpress' ),
                            'type'		 => 'textfield',
                            'param_name' => 'list_item_name',
                            'admin_label'	=> true,
                        ),
                    ),
                ),
                array(
                    "type"          => "attach_image",
                    "heading"       => __("List Marker Image", "hostingpress"),
                    "param_name"    => "list_marker_image",
                    "value"         => get_template_directory_uri() . '/images/icons/footer/list-marker.png'
                ),
                array(
                    'type' => 'font_container',
                    'param_name' => 'font_container',
                    'value' => '',
                    'settings' => array(
                        'fields' => array(
                            'color',
                            'font_size',
                            'line_height',
                            'font_size_description' => __( 'Enter font size.', 'hostingpress' ),
                            'line_height_description' => __( 'Enter line height.', 'hostingpress' ),
                            'color_description' => __( 'Select color for your element.', 'hostingpress' ),
                        ),
                    )
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Font Weight", 'hostingpress'),
                    "param_name" => "font_weight",
                    "value" => "",
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Margin Top", 'hostingpress'),
                    "param_name" => "margin_top",
                    "value" => "",
                ),
                array(
                    'type' => 'textfield',
                    'param_name' => 'class',
                    'heading' => __( 'Class', 'hostingpress' ),
                    'description' => __( 'CSS class', 'hostingpress' )
                ),
                array(
                    "type"          => "dropdown",
                    "heading"       => __("No of Column ", "hostingpress"),
                    'description'	=> __( 'How many column you want to display list', 'hostingpress' ),
                    "param_name"    => "noofcolumn",
                    "value"         => array(
                                        '1' => '1',
                                        '2' => '2',
                                        '3' => '3',
                                        '4' => '4'),
                ),
            )
        ) );
    }
}
add_action('vc_before_init', 'vc_hostingpress_list_section');


if(!function_exists('hostingpress_list_section_shortcode'))
{
    function hostingpress_list_section_shortcode($atts)
    {
        $atts = shortcode_atts(array(
            'list_details' => '',
            'list_marker_image' => '',
            'font_container' => '',
            'font_weight' => '',
            'class'    => '',
            'noofcolumn' => '1',
            'margin_top'=>''
        ), $atts);

       // tab loop
        $tab_out_result = "";
        $list_details = (array) vc_param_group_parse_atts($atts['list_details']);
        $list_data	= array();
        foreach ( $list_details as $data ) :
            $new_line 					= $data;
            $new_line['list_item_name']	= isset( $data['list_item_name'] ) ? $data['list_item_name'] : '';
            $list_data[] 			= $new_line;
        endforeach;

        $font_container_obj = new Vc_Font_Container();
        $font_container_field_settings = isset( $font_container_field['settings'], $font_container_field['settings']['fields'] ) ? $font_container_field['settings']['fields'] : array();
        $font_container_data = $font_container_obj->_vc_font_container_parse_attributes( $font_container_field_settings, $atts['font_container'] );

        //$font_container_data['values']['text_align'] = $atts['text_align'];
        $font_container_data['values']['font_weight'] = $atts['font_weight'];
        $font_container_data['values']['margin_top'] = $atts['margin_top'];

        if($atts['noofcolumn'] == '1') {
            $font_container_data['values']['width'] = '100%';
        }else  if($atts['noofcolumn'] == '2') {
            $font_container_data['values']['width'] = '50%';
        }else  if($atts['noofcolumn'] == '3') {
            $font_container_data['values']['width'] = '33%';
        }else  if($atts['noofcolumn'] == '4') {
            $font_container_data['values']['width'] = '25%';
        }
        $styles = hostingpress_get_styles($font_container_data);

        $marker_icon = is_numeric($atts['list_marker_image']) ? wp_get_attachment_image_src($atts['list_marker_image']) : $atts['list_marker_image'];
        $marker_icon = is_array($marker_icon) ? $marker_icon[0] : $marker_icon;

        $tab_out_result .= '<style>.dynamicULList li:before {background: url("'.$marker_icon.'") left center no-repeat;}</style>';
        $tab_out_result .= '<ul class="dynamicULList">';
        foreach ( $list_data as $line ) :
            $tab_out_result .= '<li';
            if( !empty( $atts['class'] ) ){
                $tab_out_result .= ' class="'.esc_attr($atts['class']).'"';
            }
            if ( ! empty( $styles ) ) {
                $tab_out_result .= ' style="' . esc_attr( implode( ';', $styles ) ) . '"';
            }
            $tab_out_result .= '>' . esc_html( $line['list_item_name'] ) . '</li>';

        endforeach;
        $tab_out_result .= '</ul>';
       // $tab_out_result .= '<style>.scroll_tab li.active a, .scroll_tab li.active a:focus,.scroll_tab li a:hover {color: '.$atts['seleccted_tab_f_color'].';background: '.$atts['seleccted_tab_bg_color'].';}..scroll_tab li a{color: '.$atts['tab_f_color'].';background: '.$atts['tab_bg_color'].';}</style>';
        return $tab_out_result;
    }
}
add_shortcode('hostingpress_liststyle', 'hostingpress_list_section_shortcode');