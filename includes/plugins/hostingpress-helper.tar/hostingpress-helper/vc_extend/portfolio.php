<?php

if(!function_exists('hostingpress_vc_portfolio'))
{
    function hostingpress_vc_portfolio() {
        vc_map( array(
            "name"  => esc_html__("Portfolio", "hostingpress" ),
            "base"  => "hostingpress_portfolio",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("CHECK OUR &", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("OUR PORTFOLIO", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Portfolio", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Portfolio", "hostingpress"),
                    'value'         => 4
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2'),
                    "std"           => 'Layout1',
                ),
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_portfolio');


if(!function_exists('hostingpress_vc_portfolio_shortcode'))
{
    function hostingpress_vc_portfolio_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('CHECK OUR &', "hostingpress"),
			'title' => esc_html__('OUR PORTFOLIO', "hostingpress"),
            'limit' => 3,
			'template' => 'Layout1',
        ), $atts);

        $query_arg = array(
            'post_type' => 'portfolio'
        );

        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }


        $pricing_plan = new WP_Query();
        $pricing_plan->query($query_arg);
		ob_start();

		if($atts['template'] == 'Layout1')
        {
			?>
			<div class="row">
			<div class="container">
			   <div class="row sectionTitle">
					<h5><?php echo esc_html($atts['sub_title']) ?></h5>
					<h2><?php echo esc_html($atts['title']) ?></h2>
				</div>
				<div class="row col3">
			<?php
			while($pricing_plan->have_posts()) : $pricing_plan->the_post();
				$post_meta = get_post_meta(get_the_ID());
				$url = wp_get_attachment_url( get_post_thumbnail_id($pricing_plan->ID) );
				?>
				<div class="col-sm-4 portfolio">
					<div class="row image m0">
						<?php the_post_thumbnail('hostingpress-portfolio-thumb', array('class' => 'img-responsive')); ?>
						<a href="<?php echo esc_url($url); ?>" class="portfolio-link"><i class="fa fa-search"></i></a>
					</div>
					<div class="row m0">
						<h5><a href="#"><?php the_title(); ?></a></h5>
						<p><?php echo esc_html($post_meta['portfolio_technology'][0]); ?></p>
					</div>
				</div>
			<?php
			endwhile;
			?>
			</div>
			</div>
			</div>
			<?php
			}
			else if($atts['template'] == 'Layout2')
			{
			?>
				<div class="row">
					<div class="container">
						<div class="row">
							<div class="sectionTitle">
								<h5><?php echo esc_html($atts['sub_title']) ?></h5>
								<h2><?php echo esc_html($atts['title']) ?></h2>
							</div>
							<?php
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$url = wp_get_attachment_url( get_post_thumbnail_id($pricing_plan->ID) );
								?>
								<div class="col-sm-6 portfolio">
									<div class="row image m0">
										<?php the_post_thumbnail('hostingpress-portfolio-largethumb', array('class' => 'img-responsive')); ?>
										<a href="<?php echo esc_url($url); ?>" class="portfolio-link"><i class="fa fa-search"></i></a>
									</div>
									<div class="row m0">
										<h5><a href="#"><?php the_title(); ?></a></h5>
										<p><?php echo esc_html($post_meta['portfolio_technology'][0]); ?></p>
									</div>
								</div>
								<?php
							endwhile;
							?>
						</div>

						</div>

				</div>
				<?php
			}
		wp_reset_postdata();
		return ob_get_clean();
    }
}
add_shortcode('hostingpress_portfolio', 'hostingpress_vc_portfolio_shortcode');