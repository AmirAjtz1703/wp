<?php

if(!function_exists('vc_hostingpress_tabbing_section'))
{
    function vc_hostingpress_tabbing_section() {
        vc_map( array(
            "name"  => __("Tabbing", "hostingpress" ),
            "base"  => "hostingpress_tabbing",
            "class" => "",
            "category" => __("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    'heading'		=> esc_html__( 'Tab Details', 'hostingpress' ),
                    'description'	=> esc_html__( 'Enter Tab name and Tab Id  ', 'hostingpress' ),
                    'type'			=> 'param_group',
                    'param_name'	=> 'tab_details',
                    'params' => array(
                        array(
                            'heading'	 => esc_html__( 'Tab Name', 'hostingpress' ),
                            'type'		 => 'textfield',
                            'param_name' => 'tab_name',
                            'admin_label'	=> true,
                        ),
                        array(
                            'heading'		=> esc_html__( 'Tab Row ID', 'hostingpress' ),
                            'type'			=> 'textfield',
                            'param_name'	=> 'tab_row_id',
                            'admin_label'	=> true,
                        ),
                    ),
                ),
                array(
                    "type"          => "colorpicker",
                    "heading"       => __("Tab Background Color", "hostingpress"),
                    "param_name"    => "tab_bg_color",
                    "value"         => "#267ae9"
                ),
                array(
                    "type"          => "colorpicker",
                    "heading"       => __("Selected Tab Background Color", "hostingpress"),
                    "param_name"    => "seleccted_tab_bg_color",
                    "value"         => "#0fa3f2"
                ),
                array(
                    "type"          => "colorpicker",
                    "heading"       => __("Tab Font Color", "hostingpress"),
                    "param_name"    => "tab_f_color",
                    "value"         => "#fff"
                ),
                array(
                    "type"          => "colorpicker",
                    "heading"       => __("Selected Tab Font Color", "hostingpress"),
                    "param_name"    => "seleccted_tab_f_color",
                    "value"         => "#fff"
                )
            )
        ) );
    }
}
add_action('vc_before_init', 'vc_hostingpress_tabbing_section');


if(!function_exists('hostingpress_tabbing_section_shortcode'))
{
    function hostingpress_tabbing_section_shortcode($atts)
    {
        $atts = shortcode_atts(array(
            'tab_details' => '',
            'tab_bg_color' => '#267ae9',
            'seleccted_tab_bg_color' => '#0fa3f2',
            'tab_f_color' => '#fff',
            'seleccted_tab_f_color' => '#fff'
        ), $atts);

       // tab loop
        $tab_out_result = "";
        $tab_details = (array) vc_param_group_parse_atts($atts['tab_details']);
        $tab_data	= array();
        foreach ( $tab_details as $data ) :
            $new_line 					= $data;
            $new_line['tab_name']	= isset( $data['tab_name'] ) ? $data['tab_name'] : '';
            $new_line['tab_row_id']	= isset( $data['tab_row_id'] ) ? $data['tab_row_id'] : '';
            $tab_data[] 			= $new_line;
        endforeach;

        $tab_out_result .= '<div class="row">';
        $tab_out_result .= '<div class="container">';
        $tab_out_result .= '<ul class="nav nav-tabs scroll_tab">';
        foreach ( $tab_data as $line ) :
            $tab_out_result .= '<li><a data-toggle="tab" href="#' . esc_html( $line['tab_row_id'] ) . '">' . esc_html( $line['tab_name'] ) . '</a></li>';
        endforeach;
        $tab_out_result .= '</ul></div></div>';
        $tab_out_result .= '<style>.scroll_tab li.active a, .scroll_tab li.active a:focus,.scroll_tab li a:hover {color: '.$atts['seleccted_tab_f_color'].';background: '.$atts['seleccted_tab_bg_color'].';}..scroll_tab li a{color: '.$atts['tab_f_color'].';background: '.$atts['tab_bg_color'].';}</style>';



        return $tab_out_result;
    }
}
add_shortcode('hostingpress_tabbing', 'hostingpress_tabbing_section_shortcode');