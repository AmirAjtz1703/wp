<?php

if(!function_exists('hostingpress_vc_faq'))
{
    function hostingpress_vc_faq() {
        vc_map( array(
            "name"  => esc_html__("FAQs", "hostingpress" ),
            "base"  => "hostingpress_faq",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("CUSTOMERS", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("FAQS", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of FAQs", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display FAQs", "hostingpress"),
                    'value'         => 4
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2', 'Layout3'),
                    "std"           => 'Layout1',
                ),
                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display FAQ's for Which Category", "hostingpress"),
                    "param_name"    => "faqcategory",
                    'value'         => hostingpress_faq_texonomy(),
                    "std"           => 'All',
                ),

            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_faq');


if(!function_exists('hostingpress_vc_faq_shortcode'))
{
    function hostingpress_vc_faq_shortcode($atts)
    {
       $atts = shortcode_atts(array(
			'sub_title' => esc_html__('CUSTOMERS', "hostingpress"),
			'title' => esc_html__('FAQS', "hostingpress"),
            'limit' => 4,
			'template' => 'Layout1',
            'faqcategory' => 'All'
        ), $atts);

        $query_arg = array(
            'post_type' => 'faq',

        );

        if(!empty($atts['faqcategory']) > 0 && $atts['faqcategory'] != 'All')
        {
            $query_arg['tax_query'] = array(
                array(
                    'taxonomy' => 'faqcategory',
                    'field'    => 'slug',
                    'terms'    => array( $atts['faqcategory']),
                ));
        }


        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }

        $faq = new WP_Query();
        $faq->query($query_arg);
		ob_start();

		if($atts['template'] == 'Layout1')
        {

			?>
				<div>
                    <div class="row sectionTitle text-left">
                        <h5><?php echo esc_html($atts['sub_title']) ?></h5>
                        <h3><?php echo esc_html($atts['title']) ?></h3>
                    </div>
                    <div class="panel-group accordion faqs" id="accordion_sc" role="tablist" aria-multiselectable="true">
				
			<?php
				$count = 1;
				while($faq->have_posts()) : $faq->the_post();
				$post_meta = get_post_meta(get_the_ID());
				$expandable = "";
				$expandable_content = "";
				if($count == 1)
				{
					$expandable = "true";
					$expandable_content = "in";
				}
				else
				{
					$expandable = "false";
					$expandable_content = "";
				}
				?>
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="heading<?php echo $count; ?>">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion_sc" href="#collapse<?php echo $count; ?>" aria-expanded="<?php echo $expandable; ?>" aria-controls="collapse<?php echo $count; ?>">
									<?php the_title(); ?>
								</a>
							</h4>
						</div>
						<div id="collapse<?php echo $count; ?>" class="panel-collapse collapse <?php echo $expandable_content; ?>" role="tabpane<?php echo $count; ?>" aria-labelledby="heading<?php echo $count; ?>">
							<div class="panel-body">
								<?php the_content(); ?>
							</div>
						</div>
					</div>
						
					
			<?php
			$count = $count + 1;
			endwhile;
			?>
			</div>
			</div>
			<?php
            }
            else if($atts['template'] == 'Layout2')
            { ?>
                <div class="row">
                    <div class="container">
                        <div class="row sectionTitle">
                            <h5><?php echo esc_html($atts['sub_title']) ?></h5>
                            <h2><?php echo esc_html($atts['title']) ?></h2>
                        </div>
                        <div class="panel-group faqs_accordion" id="faqs_accordion" role="tablist" aria-multiselectable="true">
                            <?php
                            $count = 1;
                            while($faq->have_posts()) : $faq->the_post();
                                $post_meta = get_post_meta(get_the_ID());
                                $expandable = "";
                                $expandable_content = "";
                                if($count == 1)
                                {
                                    $expandable = "true";
                                    $expandable_content = "in";
                                }
                                else
                                {
                                    $expandable = "false";
                                    $expandable_content = "";
                                }
                                ?>

                                <div class="panel panel-default">
                                    <div class="media">
                                        <div class="media-left media-middle"><span><?php echo str_pad($count,2, "0",STR_PAD_LEFT); ?></span></div>
                                        <div class="media-body">
                                            <div class="panel-heading" role="tab" id="heading<?php echo $count; ?>">
                                                <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#faqs_accordion" href="#collapse<?php echo $count; ?>" aria-expanded="<?php echo $expandable; ?>" aria-controls="collapse<?php echo $count; ?>">
                                                        <?php the_title(); ?>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapse<?php echo $count; ?>" class="panel-collapse collapse <?php echo $expandable_content; ?>" role="tabpane<?php echo $count; ?>" aria-labelledby="heading<?php echo $count; ?>">
                                                <div class="panel-body">
                                                    <?php the_content(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $count = $count + 1;
                            endwhile;
                            ?>
                        </div>
                    </div>
                </div>
            <?php
            }
            else if($atts['template'] == 'Layout3')
            { ?>
                <div class="row faqs_content">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-3 faq_category">
                                <h4 class="menuTitle"><?php echo esc_html("categories", "hostingpress") ?></h4>
                                <ul class="nav nav-tabs" role="tablist">
                                <?php
                                $faqTaxonomys = hostingpress_faq_texonomy();
                                if(!empty($faqTaxonomys))
                                {
                                    $count = 1;
                                    foreach($faqTaxonomys as $faqTaxonomy)
                                    {
                                        if ($faqTaxonomy != 'All')
                                        {
                                            $activeVal = $count == 1 ? "active" : "";
                                            //$icon_url = get_option(faqcategory_{$term_id}_icon);
                                            ?>
                                            <li role="presentation" class="<?php echo $activeVal; ?>">
                                                <a href="#faqsT<?php echo $count; ?>"
                                                   aria-controls="faqsT<?php echo $count; ?>" role="tab"
                                                   data-toggle="tab">
                                                    <img src="<?php echo get_template_directory_uri() ?>/images/icons/faqs/1.png" alt=""
                                                         class="icon"><?php echo $faqTaxonomy; ?>
                                                </a>
                                            </li>
                                            <?php $count = $count + 1;
                                        }
                                    }
                                    }?>
                                </ul>
                            </div>
                            <div class="col-sm-9 faq_content">
                                <div class="tab-content">
                                <?php
                                $faqTaxonomys = hostingpress_faq_texonomy();
                                if(!empty($faqTaxonomys))
                                {
                                    $count = 1;
                                    foreach($faqTaxonomys as $faqTaxonomy)
                                    {
                                        if ($faqTaxonomy != 'All')
                                        {
                                            $activeVal = $count == 1 ? "active" : "";
                                            ?>
                                            <div class="tab-pane <?php echo $activeVal; ?>" role="tabpanel"
                                                 id="faqsT<?php echo $count; ?>">

                                                <?php
                                                $query_argLayout3 = array(
                                                    'post_type' => 'faq',
                                                );
                                                $query_argLayout3['tax_query'] = array (array(
													'taxonomy' => 'faqcategory',
													'field' => 'slug',
													'terms' => $faqTaxonomy
												));
                                                //$query_argLayout3['category'] = $faqTaxonomy;
                                                $query_argLayout3['posts_per_page'] = '-1';
                                                $faqLayout3 = new WP_Query();
                                                $faqLayout3->query($query_argLayout3);
                                                $noOfFaq = 1;
                                                while ($faqLayout3->have_posts()) : $faqLayout3->the_post();

                                                    ?>
                                                    <div class="media faq">
                                                        <div class="media-left"><?php echo str_pad($noOfFaq,2, "0",STR_PAD_LEFT); ?></div>
                                                        <div class="media-body">
                                                            <h4><?php the_title(); ?></h4>
                                                            <?php the_content(); ?>
                                                        </div>
                                                    </div>
                                                    <?php
                                                    $noOfFaq = $noOfFaq + 1;
                                                endwhile;
                                                wp_reset_postdata();
                                                ?>
                                            </div>
                                            <?php
                                            $count = $count + 1;
                                        }
                                    }
                                }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php }
        wp_reset_postdata();
		return ob_get_clean();
    }
}
add_shortcode('hostingpress_faq', 'hostingpress_vc_faq_shortcode');