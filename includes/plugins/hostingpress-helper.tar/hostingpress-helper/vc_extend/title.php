<?php

if(!function_exists('hostingpress_vc_title_tag'))
{
    function hostingpress_vc_title_tag() {

                vc_map( array(
                    'name' => __( 'Title Styles', 'hostingpress' ),
                    'base' => 'hostingpress_title_tag',
                    'category' => esc_html__("Hosting Press", "hostingpress"),
                    'wrapper_class' => 'clearfix',
                    'description' => __( 'List of Title Styles', "hostingpress" ),
                    'params' => array(
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'type',
                            'value' => array(
                                'h1' => 'H1',
                                'h2' => 'H2',
                                'h3' => 'H3',
                                'h4' => 'H4',
                                'h5' => 'H5',
                                'h6' => 'H6',
                                'p' => 'P',
                                'strong' => 'Strong',
                            ),
                            'heading' => __( 'Head Tag', 'hostingpress' ),
                            'description' => __( 'Select Header Tag', 'hostingpress' )
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'text',
                            'heading' => __( 'Title Text', 'hostingpress' ),
                           /* 'holder' => 'div',*/
                            'value' => ''
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'text_align',
                            'value' => array(
                                '' => '--Select Align--',
                                'left' =>'Left',
                                'right' =>'Right',
                                'center' =>'Center',
                                'justify' =>'Justify',
                            ),
                            'heading' => __( 'Text Align', 'hostingpress' ),
                            'description' => __( 'Select text alignment.', 'hostingpress' )
                        ),
                        array(
                            'type' => 'font_container',
                            'param_name' => 'font_container',
                            'value' => '',
                            'settings' => array(
                                'fields' => array(
                                    'color',
                                    'font_size',
                                    'line_height',
                                    'font_size_description' => __( 'Enter font size.', 'hostingpress' ),
                                    'line_height_description' => __( 'Enter line height.', 'hostingpress' ),
                                    'color_description' => __( 'Select color for your element.', 'hostingpress' ),
                                ),
                            )
                        ),
                        array(
                            "type" => "textfield",
                            "heading" => esc_html__("Font Weight", 'hostingpress'),
                            "param_name" => "font_weight",
                            "value" => "",
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'class',
                            'heading' => __( 'Class', 'hostingpress' ),
                            'description' => __( 'CSS class', 'hostingpress' )
                        ),
                    )
                ));
    }
}
add_action('vc_before_init', 'hostingpress_vc_title_tag');


if(!function_exists('hostingpress_vc_title_tag_shortcode'))
{
    function hostingpress_vc_title_tag_shortcode($atts)
    {
        $atts = shortcode_atts(array(
            'type'   => 'h1',
            'text' => 'Sample title',
            'class'    => '',
            'font_container'    => '',
            'text_align'    => '',
            'font_weight' => '',
        ), $atts);

        $font_container_obj = new Vc_Font_Container();
        $font_container_field_settings = isset( $font_container_field['settings'], $font_container_field['settings']['fields'] ) ? $font_container_field['settings']['fields'] : array();
        $font_container_data = $font_container_obj->_vc_font_container_parse_attributes( $font_container_field_settings, $atts['font_container'] );

        $font_container_data['values']['text_align'] = $atts['text_align'];
        $font_container_data['values']['font_weight'] = $atts['font_weight'];

        $styles = hostingpress_get_styles($font_container_data);

        $_return = '';

        $_return .= '<'.esc_attr($atts['type']);
        if( !empty( $atts['class'] ) ){
            $_return .= ' class="'.esc_attr($atts['class']).'"';
        }
        if ( ! empty( $styles ) ) {
            $_return .= ' style="' . esc_attr( implode( ';', $styles ) ) . '"';
        }
        $_return .= '>';
        $_return .= $atts['text'];
        $_return .= '</'.esc_attr($atts['type']).'>';

        return 	$_return;


    }
}
add_shortcode('hostingpress_title_tag', 'hostingpress_vc_title_tag_shortcode');