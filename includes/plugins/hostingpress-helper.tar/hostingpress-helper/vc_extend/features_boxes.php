<?php

if(!function_exists('vc_hostingpress_features'))
{
    function vc_hostingpress_features() {
        vc_map( array(
            "name"  => __("Features", "hostingpress" ),
            "base"  => "hostingpress_features",
            "category" => __("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "type"          => "dropdown",
                    "heading"       => __("Style", "hostingpress"),
                    'description'	=> __( 'Select Style', 'hostingpress' ),
                    "param_name"    => "style",
                    "value"         => array(
                        '1' => 'Style 1',
                        '2' => 'Style 2','3' => 'Style 3'),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => __("Title", "hostingpress"),
                    "param_name"    => "title",
                ),
                array(
                    "type"          => "textarea",
                    "heading"       => __("Content", "hostingpress"),
                    "param_name"    => "box_content",
                ),

                array(
                    "type"          => "attach_image",
                    "heading"       => __("Feature Icon", "hostingpress"),
                    "param_name"    => "feature_icon",
                    "value"         => get_template_directory_uri() . '/images/pages/quick-blocks/4.png'
                ),
                array(
                    "type"          => "colorpicker",
                    "heading"       => __("Box Background Color", "hostingpress"),
                    "param_name"    => "box_bg_color",
                    "value"         => "#267ae9"
                ),
              /*  array(
                    "type" => "iconpicker",
                    "heading" => esc_html__( "Icon", 'hostingpress' ),
                    "param_name" => "iconname",
                    'value'=>'',
                    "description" => esc_html__( "Select Icon", 'hostingpress')
                )*/

            )
        ) );
    }
}
add_action('vc_before_init', 'vc_hostingpress_features');


if(!function_exists('hostingpress_features_shortcode'))
{
    function hostingpress_features_shortcode($atts)
    {
        $atts = shortcode_atts(array(
            'title' => '',
            'box_content' => '',
            'feature_icon' => get_template_directory_uri() . '/images/pages/quick-blocks/4.png',
            'style' => '1',
            'box_bg_color' => '',
           // 'iconname'=>''
        ), $atts);

        $title = $atts['title'];
        $feature_icon = is_numeric($atts['feature_icon']) ? wp_get_attachment_image_src($atts['feature_icon']) : $atts['feature_icon'];
        $feature_icon = is_array($feature_icon) ? $feature_icon[0] : $feature_icon;
        $content = do_shortcode($atts['box_content']);
       // $iconname = $atts['iconname'];

        $current_box_html = "";
        if($atts['style'] == 'Style 1') {
            $current_box_html .= '<div class="cause2choose">';
            $current_box_html .= '<div class="media">';
            $current_box_html .= '<div class="media-left"><a href="http://localhost/hosting/wp-content/uploads/2016/01/12.png"><img class="size-full wp-image-1712" src="' . $feature_icon . '" alt="1" width="60" height="64" /></a></div>';
            $current_box_html .= '<div class="media-body">';
            $current_box_html .= "<h4>{$title}</h4>";
            $current_box_html .= "<p>{$content}</p>";
            $current_box_html .= ' </div>';
            $current_box_html .= '</div>';
            $current_box_html .= '</div>';
        }else  if($atts['style'] == 'Style 2') {
            $current_box_html .= '<div class="futureNoxStyle2" style="background-color:' . $atts['box_bg_color'] . '">';
            $current_box_html .= '<div class="media">';
         /*   if(empty($iconname))
                $current_box_html .= '<div class="media-left"><a href="'.$feature_icon.'"><img class="size-full wp-image-1712" src="' . $feature_icon . '" alt="1" width="60" height="64" /></a></div>';
            else
                $current_box_html .= '<div class="media-left"><i class="'. $iconname .'"></i></div>';*/

            $current_box_html .= '<div class="media-left"><a href="'.$feature_icon.'"><img class="size-full wp-image-1712" src="' . $feature_icon . '" alt="1" width="60" height="64" /></a></div>';
            $current_box_html .= '<div class="media-body">';
            $current_box_html .= "<h4>{$title}</h4>";
            $current_box_html .= "<p>{$content}</p>";
            $current_box_html .= ' </div>';
            $current_box_html .= '</div>';
            $current_box_html .= '</div>';
        }else  if($atts['style'] == 'Style 3') {
            $current_box_html .= '<div class="futureBoxHeadStyle3" style="background-color:' . $atts['box_bg_color'] . '">';
            $current_box_html .= '<h4>{$title}</h4>';
            $current_box_html .= '</div>';
            $current_box_html .= '<div class="media-body">';
            $current_box_html .= "<p>{$content}</p>";
            $current_box_html .= '</div>';
        }

        return $current_box_html;

    }
}
add_shortcode('hostingpress_features', 'hostingpress_features_shortcode');