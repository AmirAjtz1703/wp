<?php

if(!function_exists('hostingpress_vc_testimonial'))
{
    function hostingpress_vc_testimonial() {
        vc_map( array(
            "name"  => esc_html__("Testimonial", "hostingpress" ),
            "base"  => "hostingpress_testimonial",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("CUSTOMERS", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("TESTIMONIAL", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Testimonial", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Testimonial", "hostingpress"),
                    'value'         => 4
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2'),
                    "std"           => 'Layout1',
                ),
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_testimonial');


if(!function_exists('hostingpress_vc_testimonial_shortcode'))
{
    function hostingpress_vc_testimonial_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('CUSTOMERS', "hostingpress"),
			'title' => esc_html__('TESTIMONIAL', "hostingpress"),
            'limit' => 3,
			'template' => 'Layout1',
        ), $atts);

        $query_arg = array(
            'post_type' => 'testimonial'
        );

        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }


        $testimonial = new WP_Query();
        $testimonial->query($query_arg);
		ob_start();
		if($atts['template'] == 'Layout1')
        {
			?>
				<div>
					<div class="row sectionTitle text-left">
						<h5><?php echo esc_html($atts['sub_title']) ?></h5>
						<h3><?php echo esc_html($atts['title']) ?></h3>
					</div>
					<div class="testimonial_slider owl-carousel">
			<?php
				$count = 1;
				while($testimonial->have_posts()) : $testimonial->the_post();
				$post_meta = get_post_meta(get_the_ID());
				
				?>
				
					<div class="item">
						<div class="row slide m0">
							<div class="fleft client_img">
								<?php the_post_thumbnail(); ?>
							</div>
							<div class="fleft content">
								<div class="counter"><?php echo str_pad($count,2, "0",STR_PAD_LEFT); ?></div>
								<div class="m0 quote">
									<?php the_content(); ?>
								</div>
								<h5 class="client_name"><?php the_title(); ?></h5>
							</div>
						</div>
					</div>
			<?php
			$count = $count + 1;
			endwhile;
			?>
			</div>
			</div>
        <?php
        }
        else if($atts['template'] == 'Layout2')
        {
        ?>
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row sectionTitle">
                                <h5>customers</h5>
                                <h2>testimonial</h2>
                            </div>
                            <div class="testimonial_slider2 owl-carousel">
                                <?php
                                $count = 1;
                                while($testimonial->have_posts()) : $testimonial->the_post();
                                    $post_meta = get_post_meta(get_the_ID());
                                    $sliderClass = "";
                                    if($count % 2 == 0)
                                    {
                                        $sliderClass = "slide2";
                                    }
                                    else
                                    {
                                        $sliderClass = "";
                                    }
                                    ?>
                                    <div class="item">
                                        <div class="row slide <?php echo $sliderClass; ?> m0">
                                            <div class="fleft client_img"> <?php the_post_thumbnail(); ?></div>
                                            <div class="fleft content">
                                                <div class="counter"><?php echo str_pad($count,2, "0",STR_PAD_LEFT); ?></div>
                                                <div class="m0 quote">
                                                    <?php the_content(); ?>
                                                </div>
                                                <h5 class="client_name"><?php the_title(); ?></h5>
                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                    $count = $count + 1;
                                endwhile;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        wp_reset_postdata();
		return ob_get_clean();	
    }
}
add_shortcode('hostingpress_testimonial', 'hostingpress_vc_testimonial_shortcode');