<?php

if(!function_exists('hostingpress_vc_blog'))
{
    function hostingpress_vc_blog() {
        vc_map( array(
            "name"  => esc_html__("Blog", "hostingpress" ),
            "base"  => "hostingpress_blog",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("LATEST", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("NEWS", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Blogs", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Blogs", "hostingpress"),
                    'value'         => 3
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2'),
                    "std"           => 'Layout1',
                ),
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_blog');


if(!function_exists('hostingpress_vc_blog_shortcode'))
{
    function hostingpress_vc_blog_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('LATEST', "hostingpress"),
			'title' => esc_html__('NEWS', "hostingpress"),
            'limit' => 3,
			'template' => 'Layout1',
        ), $atts);

        $query_arg = array(
            'post_type' => 'post'
        );

        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }


        $latest_blog = new WP_Query();
        $latest_blog->query($query_arg);
		ob_start();

		if($atts['template'] == 'Layout1')
        {
			?>
				<div class="row">
                    <div class="row sectionTitle text-left">
                        <h5><?php echo esc_html($atts['sub_title']) ?></h5>
                        <h3><?php echo esc_html($atts['title']) ?></h3>
                    </div>
					 <div class="latest_news row m0">
			<?php

				while($latest_blog->have_posts()) : $latest_blog->the_post();
				$post_meta = get_post_meta(get_the_ID());
				
				?>
					<div class="post media">
						<div class="media-left">
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail('hostingpress-thumb-small', array('class' => 'img-responsive')); ?>
							</a>
						</div>
						<div class="media-body">
							<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
							<p><?php echo hostingpress_excerpt(70); ?></p>
							<div class="row m0 timeAgo"><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' ago'; ?></div>
						</div>
					</div>
			<?php

			endwhile;
			?>
			</div>
			</div>
			
			<?php
			}
        wp_reset_postdata();
		return ob_get_clean();
    }
}
add_shortcode('hostingpress_blog', 'hostingpress_vc_blog_shortcode');