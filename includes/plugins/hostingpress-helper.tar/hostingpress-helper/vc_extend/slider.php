<?php

if(!function_exists('hostingpress_vc_carousel_slider'))
{
    function hostingpress_vc_carousel_slider() {
        vc_map( array(
            "name"  => esc_html__("Carousel Slider", "hostingpress" ),
            "base"  => "hostingpress_carousel_slider",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_carousel_slider');


if(!function_exists('hostingpress_vc_carousel_slider_shortcode'))
{
    function hostingpress_vc_carousel_slider_shortcode($atts)
    {

        $query_arg = array(
            'post_type' => 'slider'
        );

        $hosting_slider = new WP_Query();
		$hosting_slider->query($query_arg);
ob_start();

			?>
		<div class="row slider">
			<div id="home_slider3" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators">
								<?php
								$count = 0;
								while ($hosting_slider->have_posts()) : $hosting_slider->the_post();
									$post_meta = get_post_meta(get_the_ID());
									$url = wp_get_attachment_url(get_post_thumbnail_id($hosting_slider->ID));

									$icon_url = stripslashes($post_meta['slider_icon_small'][0]);
									$activeVal = $count == 0 ? "active" : "";
									?>

									<li data-target="#home_slider3" data-slide-to="<?php echo $count ?>" class="<?php echo $activeVal; ?>"><img src="<?php echo esc_url($icon_url); ?>" alt="" class="icon"><?php the_title(); ?></li>

									<?php
									$count = $count + 1;
								endwhile;
								?>
				</ol>
				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
							<?php
							$count = 0;
							while ($hosting_slider->have_posts()) : $hosting_slider->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$url = wp_get_attachment_url(get_post_thumbnail_id($hosting_slider->ID));

								$activeVal = $count == 0 ? "active" : "";
								?>

								<div class="item <?php echo $activeVal; ?>">
									<div class="carousel-caption">
										<div class="container">
											<div class="row">
												<div class="media">
													<div class="media-left media-middle">
														<img src="<?php echo esc_url($url);?>" alt="">

													</div>
													<div class="media-body">
														<h4><?php echo esc_html($post_meta['slider_title'][0]) ?></h4>
														<h2><?php echo esc_html($post_meta['slider_subtitle'][0]) ?></h2>
														<?php the_content(); ?>
														<a href="<?php echo esc_url($post_meta['slider_button_url'][0]) ?>" class="btn btn-primary"><?php echo esc_html($post_meta['slider_button_text'][0]) ?></a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<?php
								$count = $count + 1;
							endwhile;
							?>
					</div>

				<!-- Controls -->
				<a class="left carousel-control" href="#home_slider3" role="button" data-slide="prev">
					<span class='lnr lnr-chevron-left'></span>
				</a>
				<a class="right carousel-control" href="#home_slider3" role="button" data-slide="next">
					<span class='lnr lnr-chevron-right'></span>
				</a>
			</div>
		</div>

			<?php
		wp_reset_postdata();
		return ob_get_clean();	
    }
}
add_shortcode('hostingpress_carousel_slider', 'hostingpress_vc_carousel_slider_shortcode');