<?php

if(!function_exists('hostingpress_vc_pricing_table'))
{
    function hostingpress_vc_pricing_table() {
        vc_map( array(
            "name"  => esc_html__("Pricing Table", "hostingpress" ),
            "base"  => "hostingpress_pricing_table",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("our package &amp;", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("pricing plan", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Plan", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Pricing Plan", "hostingpress"),
                    'value'         => 4
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2','Layout3','Layout4','Layout5'),
                    "std"           => 'Layout1',
                ),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Display Pricing for Which Category", "hostingpress"),
					"param_name"    => "pricetype",
					'value'         => hostingpress_pricing_texonomy(),
					"std"           => 'All',
				),

            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_pricing_table');


if(!function_exists('hostingpress_vc_pricing_table_shortcode'))
{
    function hostingpress_vc_pricing_table_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('our package &amp;', "hostingpress"),
			'title' => esc_html__('pricing plan', "hostingpress"),
            'limit' => 3,
			'template' => 'Layout1',
			'pricetype' => 'All'
        ), $atts);

        $query_arg = array(
            'post_type' => 'pricing');

		if(!empty($atts['pricetype']) > 0 && $atts['pricetype'] != 'All')
		{
			$query_arg['tax_query'] = array(
			array(
				'taxonomy' => 'pricing_category',
				'field'    => 'slug',
				'terms'    => array( $atts['pricetype']),
			));
		}


        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }
		$query_arg['meta_key'] = 'pricing_order_no';
		$query_arg['orderby'] = 'meta_value';
		$query_arg['order'] = 'ASC';

		$pricing_plan = new WP_Query();
        $pricing_plan->query($query_arg);
ob_start();
		if($atts['template'] == 'Layout1') {
			?>
			<div class="row pricing">
				<div class="container">
					<div class="row sectionTitle">
						<h5><?php echo esc_html($atts['sub_title']) ?></h5>

						<h2><?php echo esc_html($atts['title']) ?></h2>
					</div>
					<div class="owl-carousel pricing_plan">
						<?php
						while ($pricing_plan->have_posts()) : $pricing_plan->the_post();
							$post_meta = get_post_meta(get_the_ID());
							$amount_font_size = "48px";
							if (isset($post_meta['pricing_amount_font_size'][0])) {
								$value = $post_meta['pricing_amount_font_size'][0];
								$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';

								$regexr = preg_match($pattern, $value, $matches);
								$value = isset($matches[1]) ? (float)$matches[1] : (float)$value;
								$unit = isset($matches[2]) ? $matches[2] : 'px';
								$amount_font_size = $value . $unit;

							}
							?>
							<div class="item">
								<div class="row m0 plan">
									<div class="price row m0">
										<span
											class="currencyType"><?php echo esc_html($post_meta['pricing_currency_sign'][0]); ?></span>
										<span class="amount"
											  style="font-size:<?php echo esc_html($amount_font_size); ?>"><?php echo esc_html($post_meta['pricing_amount'][0]); ?></span>
										<small>/<?php echo esc_html($post_meta['pricing_period'][0]); ?></small>
									</div>
									<div class="serviceType row m0">
										<h4><?php the_title(); ?></h4>
									</div>
									<p><?php the_content(); ?></p>
									<a href="<?php echo esc_html($post_meta['pricing_button_url'][0]); ?>"
									   class="btn btn-primary"><?php echo esc_html($post_meta['pricing_button_text'][0]); ?></a>
								</div>
							</div>
							<?php
						endwhile;
						?>
					</div>
					<div class="row pricing_nav">
						<div class="col-sm-4 col-sm-offset-4">
							<div id="pricing_nav" class="row m0"></div>
						</div>
					</div>
				</div>
			</div>
			<?php
			}
			else if($atts['template'] == 'Layout2')
			{
			?>
				<div class="row pricing pricing2">
					<div class="container">
						<div class="row sectionTitle">
							<h5><?php echo esc_html($atts['sub_title']) ?></h5>
							<h2><?php echo esc_html($atts['title']) ?></h2>
						</div>
						<div class="row">
							<?php
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$best_plan_css = "";
								if($post_meta['pricing_best_seller'][0] == 1)
								{
									$best_plan_css = "best_plan";
								}
								else
								{
									$best_plan_css = "";
								}
								$amount_font_size = "48px";
								if (isset($post_meta['pricing_amount_font_size'][0])) {
									$value = $post_meta['pricing_amount_font_size'][0];
									$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';

									$regexr = preg_match($pattern, $value, $matches);
									$value = isset($matches[1]) ? (float)$matches[1] : (float)$value;
									$unit = isset($matches[2]) ? $matches[2] : 'px';
									$amount_font_size = $value . $unit;

								}
								?>
								<div class="col-sm-4 price_plan <?php echo $best_plan_css; ?>">
									<div class="row inner m0">
										<div class="plan_intro">
											<div class="price row m0">
												<span class="currencyType"><?php echo esc_html($post_meta['pricing_currency_sign'][0]); ?></span>
												<span class="amount" style="font-size:<?php echo esc_html($amount_font_size); ?>"><?php echo esc_html($post_meta['pricing_amount'][0]); ?></span>
												<small>/<?php echo esc_html($post_meta['pricing_period'][0]); ?></small>
											</div>
											<div class="planType row m0">
												<h4><?php the_title(); ?></h4>
											</div>
										</div>
										<div class="m0 service_provide_row">
											<ul class="nav service_provide">

												<?php
												$pricing_attributes = get_post_meta(get_the_ID(), 'pricing_attributes', true);

												if(!empty($pricing_attributes)) {
													foreach ($pricing_attributes as $pricing_att) { ?>
														<li><?php echo esc_html($pricing_att); ?></li>
														<?php
													}
												}
												?>
											</ul>
											<a href="<?php echo esc_html($post_meta['pricing_button_url'][0]); ?>" class="btn btn-primary"><?php echo esc_html($post_meta['pricing_button_text'][0]); ?></a>
										</div>
									</div>
								</div>
								<?php
							endwhile;
							?>
						</div>
						<div class="row pricing_nav">
							<div class="col-sm-4 col-sm-offset-4">
								<div id="pricing_nav" class="row m0"></div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
			else if($atts['template'] == 'Layout3')
			{
				?>
				<div class="row pricing_plan_table">
				<div class="container">
				<div class="row sectionTitle">
					<h5><?php echo esc_html($atts['sub_title']) ?></h5>
					<h2><?php echo esc_html($atts['title']) ?></h2>
				</div>
				<div class="table-responsive">

							<?php
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$best_plan_css = "";
								if($post_meta['pricing_best_seller'][0] == 1)
								{
									$best_plan_css = "best_plan";
								}
								else
								{
									$best_plan_css = "";
								}
								$amount_font_size = "48px";
								if (isset($post_meta['pricing_amount_font_size'][0])) {
									$value = $post_meta['pricing_amount_font_size'][0];
									$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';

									$regexr = preg_match($pattern, $value, $matches);
									$value = isset($matches[1]) ? (float)$matches[1] : (float)$value;
									$unit = isset($matches[2]) ? $matches[2] : 'px';
									$amount_font_size = $value . $unit;

								}
								?>
								<div class="col-sm-4 pricing_plan_cell">
									<div class="row plan_type silver"><?php the_title();?>
										<?php
									if($best_plan_css != "")
									{?>
										<span>popular</span>
									<?php } ?>
									</div>
									<div class="row pricing_row">
										<div class="row m0 price">
											<span class="currencyType"><?php echo esc_html($post_meta['pricing_currency_sign'][0]); ?></span>
											<span class="amount" style="font-size:<?php echo esc_html($amount_font_size); ?>"><?php echo esc_html($post_meta['pricing_amount'][0]); ?></span>
											<small>/<?php echo esc_html($post_meta['pricing_period'][0]); ?></small>
										</div>
									</div>
									<div class="row nav_a">
										<ul class="nav">
											<?php
											$pricing_attributes = get_post_meta(get_the_ID(), 'pricing_attributes', true);

											if(!empty($pricing_attributes)) {
												foreach ($pricing_attributes as $pricing_att) { ?>
													<li><?php echo esc_html($pricing_att); ?></li>
													<?php
												}
											}
											?>

										</ul>
										<a href="<?php echo esc_html($post_meta['pricing_button_url'][0]); ?>" class="btn btn-primary"><?php echo esc_html($post_meta['pricing_button_text'][0]); ?></a>
									</div>
								</div>
								<?php
							endwhile;
							?>
						</div>
					</div>
				</div>
				<?php
			}
			else if($atts['template'] == 'Layout4')
			{
				?>
				<div class="row pricing_plan_table">
					<div class="container">

						<div class="table-slick">
							<?php
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$best_plan_css = "";
								if($post_meta['pricing_best_seller'][0] == 1)
								{
									$best_plan_css = "best_plan";
								}
								else
								{
									$best_plan_css = "";
								}
								$amount_font_size = "48px";
								if (isset($post_meta['pricing_amount_font_size'][0])) {
									$value = $post_meta['pricing_amount_font_size'][0];
									$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';

									$regexr = preg_match($pattern, $value, $matches);
									$value = isset($matches[1]) ? (float)$matches[1] : (float)$value;
									$unit = isset($matches[2]) ? $matches[2] : 'px';
									$amount_font_size = $value . $unit;

								}
								?>
								<div class="pricing_plan_cell  col-md-4 <?php the_ID(); ?>">
									<div class="plan_type silver">
										<?php the_title();?>
										<?php
										if($best_plan_css != "")
										{?>
											<span>popular</span>
										<?php } ?>
										<input type="hidden" value="<?php echo esc_html($post_meta['pricing_tabtitle'][0]); ?>" class="hiddentitle">
									</div>
									<div class="pricing_row">
										<div class="m0 price">
											<span class="currencyType"><?php echo esc_html($post_meta['pricing_currency_sign'][0]); ?></span>
											<span class="amount" style="font-size:<?php echo esc_html($amount_font_size); ?>"><?php echo esc_html($post_meta['pricing_amount'][0]); ?></span>
											<small>/<?php echo esc_html($post_meta['pricing_period'][0]); ?></small>
										</div>
									</div>
									<div class="nav_a">
										<ul class="nav">
											<?php
											$pricing_attributes = get_post_meta(get_the_ID(), 'pricing_attributes', true);

											if(!empty($pricing_attributes)) {
												foreach ($pricing_attributes as $pricing_att) { ?>
													<li><?php echo esc_html($pricing_att); ?></li>
													<?php
												}
											}
											?>

										</ul>
										<a href="<?php echo esc_html($post_meta['pricing_button_url'][0]); ?>" class="btn btn-primary"><?php echo esc_html($post_meta['pricing_button_text'][0]); ?></a>
									</div>
								</div>
								<?php
							endwhile;
							?>
						</div>
					</div>
				</div>
				<?php
			}else if($atts['template'] == 'Layout5')
			{
				?>
				  <div id="uncapped-products">
				<div class="uncapped-slider">
					<ul class="slider-speeds">
						<span class="arrow" data-direction="left">Previous</span>
							<?php
							$pricingTabs = array();
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$pricingTabs[] = $post_meta['pricing_tabtitle'][0];
							endwhile;
							$pricingUniqueTabs = array_unique($pricingTabs);
							foreach($pricingUniqueTabs as $pricingUniqueTab)
							{
							?>
								<li><?php echo $pricingUniqueTab; ?></li>                         
							<?php } ?>
						<span class="arrow" data-direction="right">Next</span>
					</ul>
					
				</div>
				
				
				 <div class="product-holder waypoint">
					<div class="arrow" data-direction="left"></div>
					<div class="arrow" data-direction="right"></div>
					
					<div class="product-holder-inner">
						
							 
							<?php
							$count =0;
							while($pricing_plan->have_posts()) : $pricing_plan->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$best_plan_css = "";
								if($post_meta['pricing_best_seller'][0] == 1)
								{
									$best_plan_css = "best_plan";
								}
								else
								{
									$best_plan_css = "";
								}
								$amount_font_size = "48px";
								if (isset($post_meta['pricing_amount_font_size'][0])) {
									$value = $post_meta['pricing_amount_font_size'][0];
									$pattern = '/^(\d*(?:\.\d+)?)\s*(px|\%|in|cm|mm|em|rem|ex|pt|pc|vw|vh|vmin|vmax)?$/';

									$regexr = preg_match($pattern, $value, $matches);
									$value = isset($matches[1]) ? (float)$matches[1] : (float)$value;
									$unit = isset($matches[2]) ? $matches[2] : 'px';
									$amount_font_size = $value . $unit;

								}
								
								if($count % 2 == 0)
								{ 
								?>
								
								<div class="product-group">
								<?php } ?>
								<div class="product pricing_plan_cell <?php the_ID(); ?>">
									<div class="plan_type silver">
										<?php the_title();?>
										<?php
										if($best_plan_css != "")
										{?>
											<span>popular</span>
										<?php } ?>
										<input type="hidden" value="<?php echo esc_html($post_meta['pricing_tabtitle'][0]); ?>" class="hiddentitle">
									</div>
									<div class="pricing_row">
										<div class="m0 price">
											<span class="currencyType"><?php echo esc_html($post_meta['pricing_currency_sign'][0]); ?></span>
											<span class="amount" style="font-size:<?php echo esc_html($amount_font_size); ?>"><?php echo esc_html($post_meta['pricing_amount'][0]); ?></span>
											<small>/<?php echo esc_html($post_meta['pricing_period'][0]); ?></small>
										</div>
									</div>
									<div class="nav_a">
										<ul class="nav">
											<?php
											$pricing_attributes = get_post_meta(get_the_ID(), 'pricing_attributes', true);

											if(!empty($pricing_attributes)) {
												foreach ($pricing_attributes as $pricing_att) { ?>
													<li><?php echo esc_html($pricing_att); ?></li>
													<?php
												}
											}
											?>

										</ul>
										<a href="<?php echo esc_html($post_meta['pricing_button_url'][0]); ?>" class="btn btn-primary"><?php echo esc_html($post_meta['pricing_button_text'][0]); ?></a>
									</div>
								</div>
								<?php
									if($count % 2 != 0)
								{
								?>
								
								</div>
								<?php } ?>
								
								<?php
								$count = $count + 1;
							endwhile;
							?>
						</div>
					</div>
				</div>
				</div>
				<?php
			}

		wp_reset_postdata();
		return ob_get_clean();
    }
}
add_shortcode('hostingpress_pricing_table', 'hostingpress_vc_pricing_table_shortcode');