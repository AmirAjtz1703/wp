<?php

if(!function_exists('hostingpress_vc_client'))
{
    function hostingpress_vc_client() {
        vc_map( array(
            "name"  => esc_html__("CLients", "hostingpress" ),
            "base"  => "hostingpress_client",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
			"params" => array(
				array(
					"type"          => "textfield",
					"heading"       => esc_html__("No. of Clients logo", "hostingpress"),
					"param_name"    => "limit",
					"description"   => esc_html__("Limit to maximum display CLients logo", "hostingpress"),
					'value'         => 4
				),
				array(
					"type"          => "textfield",
					"heading"       => esc_html__("Margin between 2 logo", "hostingpress"),
					"param_name"    => "margin",
					'value'         => 30,
				)
			)

		) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_client');

if(!function_exists('hostingpress_vc_client_shortcode'))
{
    function hostingpress_vc_client_shortcode($atts)
	{
		$atts = shortcode_atts(array(
			'limit' => 4,
			'margin' => 30
		), $atts);

		$query_arg = array(
			'post_type' => 'clients'
		);

		if ($atts['limit'] > 0 && is_numeric($atts['limit'])) {
			$query_arg['posts_per_page'] = $atts['limit'];
		}

		$hosting_clients = new WP_Query();
		$hosting_clients->query($query_arg);
		ob_start();

		?>
	<div class="row">
		<div class="container">
			<div id="owl-demo" class="owl-carousel owl-theme">
				<?php
				while ($hosting_clients->have_posts()) : $hosting_clients->the_post();
					$post_meta = get_post_meta(get_the_ID());
					$url = wp_get_attachment_url(get_post_thumbnail_id($hosting_clients->ID));
					?>
					<div class="item"><img src="<?php echo esc_url($url); ?>" alt="<?php the_title(); ?>"></div>
					<?php

				endwhile;
				?>
			</div>
		</div>
	</div>


		<?php
		wp_reset_postdata();
			return ob_get_clean();	
	}
}
add_shortcode('hostingpress_client', 'hostingpress_vc_client_shortcode');