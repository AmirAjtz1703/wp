<?php

if(!function_exists('hostingpress_vc_hosting_service'))
{
    function hostingpress_vc_hosting_service() {
        vc_map( array(
            "name"  => esc_html__("Hosting Service", "hostingpress" ),
            "base"  => "hostingpress_hosting_service",
            "class" => "",
            "category" => esc_html__("Hosting Press", "hostingpress"),
            'admin_enqueue_js' => '',
            'admin_enqueue_css' => '',
            "show_settings_on_create" => false,
            "params" => array(
                 array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Sub Title", "hostingpress"),
                    "value"         => esc_html__("CHECK OUR &", "hostingpress"),
                    "param_name"    => "sub_title",
                ),
				array(
                    "type"          => "textfield",
                    "class"         => "",
                    "heading"       => esc_html__("Title", "hostingpress"),
                    "value"         => esc_html__("OUR PORTFOLIO", "hostingpress"),
                    "param_name"    => "title",
                ),
				array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("No. of Hosting Service", "hostingpress"),
                    "param_name"    => "limit",
                    "description"   => esc_html__("Limit to maximum display Hosting Service", "hostingpress"),
                    'value'         => 4
                ),
				array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Display Layout", "hostingpress"),
                    "param_name"    => "template",
                    'value'         => array('Layout1', 'Layout2'),
                    "std"           => 'Layout1',
                ),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Display Hosting Services for Which Category", "hostingpress"),
					"param_name"    => "servicetype",
					'value'         => hostingpress_service_texonomy(),
					"std"           => 'All',
				),
            )
        ) );
    }
}
add_action('vc_before_init', 'hostingpress_vc_hosting_service');


if(!function_exists('hostingpress_vc_hosting_service_shortcode'))
{
    function hostingpress_vc_hosting_service_shortcode($atts)
    {
        $atts = shortcode_atts(array(
			'sub_title' => esc_html__('CHECK OUR &', "hostingpress"),
			'title' => esc_html__('OUR PORTFOLIO', "hostingpress"),
            'limit' => 3,
			'template' => 'Layout1',
			'servicetype' => 'All'
        ), $atts);

        $query_arg = array(
            'post_type' => 'hosting'
        );

		if(!empty($atts['servicetype']) > 0 && $atts['servicetype'] != 'All')
		{
			$query_arg['tax_query'] = array(
				array(
					'taxonomy' => 'service_category',
					'field'    => 'slug',
					'terms'    => array( $atts['servicetype'])
				));
		}

        if($atts['limit'] > 0 && is_numeric($atts['limit']))
        {
            $query_arg['posts_per_page'] = $atts['limit'];
        }


        $hosting_service = new WP_Query();
		$hosting_service->query($query_arg);
ob_start();
		if($atts['template'] == 'Layout1')
        {
			?>
			<div class="serviceTab">
				<div class="row service_tab_menu m0">
					<div class="container">
						<div class="row">
							<ul class="nav nav-tabs nav-justified" role="tablist">
							<?php
							$count = 1;
							$activeVal ="";
							while($hosting_service->have_posts()) : $hosting_service->the_post();
								$post_meta = get_post_meta(get_the_ID());
								$url = wp_get_attachment_url( get_post_thumbnail_id($hosting_service->ID) );

								$icon_url = stripslashes($post_meta['hosting_service_icon_small'][0]);
								$activeVal = $count == 1 ? "active" : "";
								?>
								<li role="presentation" class="<?php echo $activeVal; ?>">
									<a href="#serviceT<?php echo $count ?>" aria-controls="serviceT<?php echo $count; ?>" role="tab" data-toggle="tab">
										<img src="<?php echo esc_url($icon_url); ?>" alt="" class="icon"><?php the_title(); ?>
									</a>
								</li>
							<?php
							$count = $count + 1;
							endwhile;
							?>
							</ul>
						</div>
					</div>
				</div>
				<div class="container serviceTab_contents">
					<div class="row">
						<div class="tab-content">
							<?php
							$count = 1;
							while($hosting_service->have_posts()) : $hosting_service->the_post();
								$post_meta = get_post_meta(get_the_ID());
								//$url = wp_get_attachment_url( get_post_thumbnail_id($hosting_service->ID) );

								$icon_url = stripslashes($post_meta['hosting_service_icon_large'][0]);
								$activeVal = $count == 1 ? "active" : "";
								$currency = "$";
								if(isset($post_meta['hosting_currency'][0]))
									$currency = $post_meta['hosting_currency'][0];
								?>
								<div class="tab-pane <?php echo $activeVal; ?>" role="tabpanel" id="serviceT<?php echo $count; ?>">
									<div class="col-sm-4">
										<h3 class="title"><?php the_title(); ?></h3>
										<?php the_content(); ?>
										<a href="<?php echo esc_url($post_meta['hosting_button_url'][0]) ?>" class="btn btn-primary"><?php echo esc_html($post_meta['hosting_button_text'][0]) ?></a>
									</div>
									<div class="col-sm-7 col-sm-offset-1">
										<?php the_post_thumbnail('hostingpress-service-thumb', array('class' => 'img-responsive service_img fright')); ?>

										<img src="<?php echo esc_url($icon_url); ?>" alt="" class="img-responsive service_ico">
										<div class="row m0 rent"><span><?php echo esc_html($currency) ?></span><?php echo esc_html($post_meta['hosting_amount'][0]) ?><small><?php echo esc_html($post_meta['hosting_period'][0]) ?></small></div>
									</div>
								</div>
								<?php
								$count = $count + 1;
							endwhile;
							?>
						</div>
           			</div>
       			 </div>
    		</div>

			<?php
			}
			else if($atts['template'] == 'Layout2')
			{
			?>
				<div class="serviceTab serviceTab_byside">
					<div class="container">
						<div class="row">
							<div class="col-sm-3">
								<div class="row service_tab_menu">
									<ul class="nav nav-tabs" role="tablist">
									<?php
									$count = 1;
									while($hosting_service->have_posts()) : $hosting_service->the_post();
										$post_meta = get_post_meta(get_the_ID());
										//$url = wp_get_attachment_url( get_post_thumbnail_id($hosting_service->ID) );

										$icon_url = stripslashes($post_meta['hosting_service_icon_small'][0]);
										$activeVal = $count == 1 ? "active" : "";
										?>
										<li role="presentation" class="<?php echo $activeVal; ?>">
											<a href="#serviceT<?php echo $count; ?>" aria-controls="serviceT<?php echo $count; ?>" role="tab" data-toggle="tab">
												<img src="<?php echo esc_url($icon_url) ?>" alt="" class="icon"><?php the_title(); ?>
											</a>
										</li>
										<?php
										$count = $count + 1;
									endwhile;
									?>
									</ul>
								</div>
							</div>
							<div class="col-sm-9">
								<div class="row m0 serviceTab_contents">
									<div class="tab-content">
								<?php
								$count = 1;
								while($hosting_service->have_posts()) : $hosting_service->the_post();
									$post_meta = get_post_meta(get_the_ID());
									//$url = wp_get_attachment_url( get_post_thumbnail_id($hosting_service->ID) );
									$icon_url = stripslashes($post_meta['hosting_service_icon_large'][0]);
									$activeVal = $count == 1 ? "active" : "";
									$currency = "$";
									if(isset($post_meta['hosting_currency'][0]))
										$currency = $post_meta['hosting_currency'][0];
									?>

									<div class="tab-pane <?php echo $activeVal; ?>" role="tabpanel" id="serviceT<?php echo $count; ?>">
										<div class="col-sm-6 ico_pic">
											<?php the_post_thumbnail('hostingpress-service-thumb', array('class' => 'img-responsive service_img fright')); ?>
											<img src="<?php echo esc_url($icon_url) ?>" alt="" class="img-responsive service_ico">
										</div>
										<div class="col-sm-6 texts">
											<h3 class="title"><?php the_title(); ?></h3>
											<?php the_content(); ?>
											<a href="<?php echo esc_url($post_meta['hosting_button_url'][0]) ?>" class="btn btn-primary"><?php echo esc_html($post_meta['hosting_button_text'][0]) ?></a>
											<a href="<?php echo esc_url($post_meta['hosting_amount'][0]) ?>" class="pkg_price"><?php echo esc_html($currency) ?><?php echo esc_html($post_meta['hosting_amount'][0]) ?></a>
										</div>
									</div>

									<?php
									$count = $count + 1;
								endwhile;
								?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		wp_reset_postdata();
		return ob_get_clean();	
    }
}
add_shortcode('hostingpress_hosting_service', 'hostingpress_vc_hosting_service_shortcode');