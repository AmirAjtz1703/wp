<?php


/* Create header options meta boxes */
if(!function_exists('hostingpress_pageattributes_options_metaboxes'))
{
    function hostingpress_pageattributes_options_metaboxes()
    {

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'page_attributes',
            'title'         => esc_html__('Page Attributes', 'hostingpress'),
            'object_types'  => array('page', 'post','clients','faq','hosting','portfolio','pricing','team','testimonial'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Select Header', 'hostingpress'),
            'id'    => 'header_style',
            'type'  => 'select',
            'options' => array(0 => esc_html__('Select header style', 'hostingpress')) + hostingpress_get_header_styles()
        ));

    }
}

add_action('cmb2_init', 'hostingpress_pageattributes_options_metaboxes');


/* Create Hosting Service meta boxes */
if(!function_exists('hostingpress_hosting_service_metaboxes'))
{
    function hostingpress_hosting_service_metaboxes()
    {
        $prefix = 'hosting_';

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'hosting_service_information',
            'title'         => esc_html__('Hosting Service Information', 'hostingpress'),
            'object_types'  => array('hosting'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Amount', 'hostingpress'),
            'id'    => $prefix . 'amount',
            'type'  => 'text',
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Currency Sign', 'hostingpress'),
            'id'    => $prefix . 'currency',
            'type'  => 'text',
        ));



        $cmb->add_field(array(
            'name'  => esc_html__('Period', 'hostingpress'),
            'id'    => $prefix . 'period',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Service ICON Small', 'hostingpress'),
            'desc' 	=> esc_html__('Upload service icon image.(Size : 50 x 43)', 'hostingpress'),
            'id'    => $prefix .'service_icon_small',
            'type'  => 'file'
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Service ICON Large', 'hostingpress'),
            'desc' 	=> esc_html__('Upload service icon image.(Size : 500 x 500)', 'hostingpress'),
            'id'    => $prefix .'service_icon_large',
            'type'  => 'file'
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button Text', 'hostingpress'),
            'id'    => $prefix . 'button_text',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button URL', 'hostingpress'),
            'id'    => $prefix . 'button_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));

    }
}
add_action('cmb2_init', 'hostingpress_hosting_service_metaboxes');
/* Create Slider meta boxes */
if(!function_exists('hostingpress_slider_metaboxes'))
{
    function hostingpress_slider_metaboxes()
    {
        $prefix = 'slider_';

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'slider_information',
            'title'         => esc_html__('Slider Information', 'hostingpress'),
            'object_types'  => array('slider'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Slider Title', 'hostingpress'),
            'id'    => $prefix . 'title',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Slider Sub Title', 'hostingpress'),
            'id'    => $prefix . 'subtitle',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Slider ICON Small', 'hostingpress'),
            'desc' 	=> esc_html__('Upload Slider icon image.(Size : 50 x 43)', 'hostingpress'),
            'id'    => $prefix .'icon_small',
            'type'  => 'file'
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button Text', 'hostingpress'),
            'id'    => $prefix . 'button_text',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button URL', 'hostingpress'),
            'id'    => $prefix . 'button_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));

    }
}
add_action('cmb2_init', 'hostingpress_slider_metaboxes');


/* Create team meta boxes */
if(!function_exists('hostingpress_team_metaboxes'))
{
    function hostingpress_team_metaboxes()
    {
        $prefix = 'team_';

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'team_information',
            'title'         => esc_html__('Team Information', 'hostingpress'),
            'object_types'  => array('team'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Introduction Text', 'hostingpress'),
            'id'    => $prefix . 'introduction_text',
            'type'  => 'textarea_small',
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Designation', 'hostingpress'),
            'id'    => $prefix . 'designation',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Facebook URL', 'hostingpress'),
            'id'    => $prefix . 'facebook_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Twitter URL', 'hostingpress'),
            'id'    => $prefix . 'twitter_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Google Plus URL', 'hostingpress'),
            'id'    => $prefix . 'google_plus_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));
        $cmb->add_field(array(
            'name'  => esc_html__('LinkedIn URL', 'hostingpress'),
            'id'    => $prefix . 'linkedin_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));
    }
}

add_action('cmb2_init', 'hostingpress_team_metaboxes');

/* Create Pricing table meta boxes */
if(!function_exists('hostingpress_pricing_table_metaboxes'))
{
    function hostingpress_pricing_table_metaboxes()
    {
        $prefix = 'pricing_';

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'pricing_table_information',
            'title'         => esc_html__('Pricing Table Information', 'hostingpress'),
            'object_types'  => array('pricing'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Tab Title', 'hostingpress'),
            'id'    => $prefix . 'tabtitle',
            'type'  => 'text',
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Amount', 'hostingpress'),
            'id'    => $prefix . 'amount',
            'type'  => 'text',
        ));
        $cmb->add_field(array(
            'name'  => esc_html__('Amount Font Size', 'hostingpress'),
            'id'    => $prefix . 'amount_font_size',
            'type'  => 'text',
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Period', 'hostingpress'),
            'id'    => $prefix . 'period',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Best Seller', 'hostingpress'),
            'id'    => $prefix . 'best_seller',
            'type'             => 'radio',
            'show_option_none' => false,
            'repeatable' => false,
            'options'          => array(
                '1' => __( 'Yes', 'hostingpress' ),
                '0'   => __( 'No', 'hostingpress' ),
            ),
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Currency Sign', 'hostingpress'),
            'id'    => $prefix . 'currency_sign',
            'type'  => 'text',
            'repeatable' => false
        ));
        $cmb->add_field(array(
            'name'  => esc_html__('Attributes', 'hostingpress'),
            'id'    => $prefix . 'attributes',
            'type'  => 'text',
            'repeatable' => true
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button Text', 'hostingpress'),
            'id'    => $prefix . 'button_text',
            'type'  => 'text',
            'repeatable' => false
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Button URL', 'hostingpress'),
            'id'    => $prefix . 'button_url',
            'type'  => 'text_url',
            'protocols' => array('http', 'https')
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Display Order', 'hostingpress'),
            'id'    => $prefix . 'order_no',
            'type'  => 'text',
            'repeatable' => false
        ));

    }
}

add_action('cmb2_init', 'hostingpress_pricing_table_metaboxes');



/* Create doctor meta boxes */
if(!function_exists('hostingpress_portfolio_metaboxes'))
{
    function hostingpress_portfolio_metaboxes()
    {
        $prefix = 'portfolio_';

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'portfolio_information',
            'title'         => esc_html__('Portfolio Information', 'hostingpress'),
            'object_types'  => array('portfolio'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Technology', 'hostingpress'),
            'id'    => $prefix . 'technology',
            'type'  => 'text',
            'repeatable' => false
        ));

    }
}

add_action('cmb2_init', 'hostingpress_portfolio_metaboxes');


/* Create Post meta boxes for Video post Type*/
if(!function_exists('hostingpress_video_metaboxes'))
{
    function hostingpress_video_metaboxes()
    {

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'video_meta_box',
            'title'         => esc_html__('Video Information', 'hostingpress'),
            'object_types'  => array('post'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Video Embed Code', 'hostingpress'),
            'id'    => 'video_embed_code',
            'type'  => 'textarea_small'
        ));
    }
}

add_action('cmb2_init', 'hostingpress_video_metaboxes');


/* Create Post meta boxes for Audio post Type*/
if(!function_exists('hostingpress_audio_metaboxes'))
{
    function hostingpress_audio_metaboxes()
    {

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'audio_meta_box',
            'title'         => esc_html__('Audio Information', 'hostingpress'),
            'object_types'  => array('post'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('MP3 Audio File', 'hostingpress'),
			'desc' 	=> esc_html__('Upload the MP3 audio file.', 'hostingpress'),
            'id'    => 'mp3_audio_file',
            'type'  => 'file'
        ));
		
		$cmb->add_field(array(
            'name'  => esc_html__('Audio Embed Code', 'hostingpress'),
			'desc' => esc_html__('If you do not have audio files to upload, then you can provide audio embed code here.', 'hostingpress'),
            'id'    => 'audio_embed_code',
            'type'  => 'textarea_small'
        ));
    }
}

add_action('cmb2_init', 'hostingpress_audio_metaboxes');

/* Create Post meta boxes for Gallay post Type*/
if(!function_exists('hostingpress_gallary_metaboxes'))
{
    function hostingpress_gallary_metaboxes()
    {
        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'gallery_meta_box',
            'title'         => esc_html__('Gallery Information', 'hostingpress'),
            'object_types'  => array('post'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Gallery Images', 'hostingpress'),
			'desc' => esc_html__('An image should have minimum width of 732px and minimum height of 447px ( Bigger size images will be cropped automatically).', 'hostingpress'),
            'id'    => 'gallery',
            'type'  => 'file_list'
        ));

    }
}
add_action('cmb2_init', 'hostingpress_gallary_metaboxes');

/* Create Post meta boxes for Quote post Type*/
if(!function_exists('hostingpress_quote_metaboxes'))
{
    function hostingpress_quote_metaboxes()
    {

        /**
         * Initiate the metabox
         */
        $cmb = new_cmb2_box(array(
            'id'            => 'quote_meta_box',
            'title'         => esc_html__('Quote Information', 'hostingpress'),
            'object_types'  => array('post'), // Post type
            'context'       => 'normal',
            'priority'      => 'high',
            'show_names'    => true, // Show field names on the left
        ));

        $cmb->add_field(array(
            'name'  => esc_html__('Quote Text', 'hostingpress'),
            'id'    => 'quote_text',
            'type'  => 'textarea_small'
        ));
		
		 $cmb->add_field(array(
            'name'  => esc_html__('Quote Author', 'hostingpress'),
            'id'    => 'quote_author',
            'type'  => 'text'
        ));
    }
}
add_action('cmb2_init', 'hostingpress_quote_metaboxes');



