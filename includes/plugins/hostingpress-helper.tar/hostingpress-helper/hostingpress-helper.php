<?php
/*
Plugin Name: HostingPress Theme Helper
Plugin URI: http://themedesigner.in/
Description: Help Themes of Hosting Press works correctly.
Version: 2.1
Author: themedesigner.in
Author URI: http://themedesigner.in

*/
$plugin_dir_path = plugin_dir_path( __FILE__ );

/*-----------------------------------------------------------------------------------*/
/*	Post Type
/*-----------------------------------------------------------------------------------*/
require_once ( $plugin_dir_path .'/post-type/testimonial.php');
require_once ( $plugin_dir_path .'/post-type/team.php');
require_once ( $plugin_dir_path .'/post-type/portfolio.php');
require_once ( $plugin_dir_path .'/post-type/faq.php');
require_once ( $plugin_dir_path .'/post-type/pricing_table.php');
require_once ( $plugin_dir_path .'/post-type/hosting_services.php');
require_once ( $plugin_dir_path .'/post-type/slider.php');
require_once ( $plugin_dir_path .'/post-type/megamenu.php');
require_once ( $plugin_dir_path .'/post-type/clients.php');


/*-----------------------------------------------------------------------------------*/
/*	Visual Component
/*-----------------------------------------------------------------------------------*/
require_once ( $plugin_dir_path .'/vc_extend/pricing_table.php');
require_once ( $plugin_dir_path .'/vc_extend/testimonial.php');
require_once ( $plugin_dir_path .'/vc_extend/latest_blog.php');
require_once ( $plugin_dir_path .'/vc_extend/faq.php');
require_once ( $plugin_dir_path .'/vc_extend/our_team.php');
require_once ( $plugin_dir_path .'/vc_extend/portfolio.php');
require_once ( $plugin_dir_path .'/vc_extend/hosting_services.php');
require_once ( $plugin_dir_path .'/vc_extend/title.php');
require_once ( $plugin_dir_path .'/vc_extend/slider.php');
require_once ( $plugin_dir_path .'/vc_extend/features_boxes.php');
require_once ( $plugin_dir_path .'/vc_extend/clients.php');
require_once ( $plugin_dir_path .'/vc_extend/tabbing_section.php');
require_once ( $plugin_dir_path .'/vc_extend/list_style.php');


/*-----------------------------------------------------------------------------------*/
/*	Include Meta boxes config
/*-----------------------------------------------------------------------------------*/
require_once ( $plugin_dir_path . 'metaboxes.php');

/*-----------------------------------------------------------------------------------*/
/*	Get available header style list
/*-----------------------------------------------------------------------------------*/
if(!function_exists('hostingpress_get_header_styles'))
{
    function hostingpress_get_header_styles()
    {
        return array(
            '1' => esc_html__('Header Style 1', 'hostingpress'),
            '2' => esc_html__('Header Style 2', 'hostingpress')
        );
    }
}


if (!function_exists('hostingpress_faq_texonomy')) {
    function hostingpress_faq_texonomy()
    {
        $faqTaxonomy = array("All" => "All");
        $taxonomies = get_terms( 'faqcategory', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
        if ($taxonomies) {
            foreach ($taxonomies as $taxonomy)
            {
                $faqTaxonomy[$taxonomy->slug] = $taxonomy->slug;


            }
        }
        return $faqTaxonomy;
    }
}
if (!function_exists('hostingpress_pricing_texonomy')) {
    function hostingpress_pricing_texonomy()
    {
        $pricingTaxonomy = array("All" => "All");
        $priceTaxonomies = get_terms( 'pricing_category', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
        if ($priceTaxonomies) {
            foreach ($priceTaxonomies as $pricetaxonomy)
            {

                $pricingTaxonomy[$pricetaxonomy->slug] = $pricetaxonomy->slug;

            }
        }
        return $pricingTaxonomy;
    }
}

if (!function_exists('hostingpress_service_texonomy')) {
    function hostingpress_service_texonomy()
    {
        $serviceTaxonomy = array("All" => "All");
        $serviceTaxonomies = get_terms( 'service_category', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
        if ($serviceTaxonomies) {
            foreach ($serviceTaxonomies as $servicetaxonomy)
            {

                $serviceTaxonomy[$servicetaxonomy->slug] = $servicetaxonomy->slug;

            }
        }
        return $serviceTaxonomy;
    }
}